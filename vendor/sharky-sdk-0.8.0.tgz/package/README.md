# @sharky/sdk

Official client SDK for the [Sharky](https://sharky.dev) platform. One small,
dependency-free client to consume everything a published site needs — catalog
(portfolio/products), blog posts, categories & tags, site metadata and contact
capture.

```bash
npm install @sharky/sdk
```

## Quick start

```ts
import { Sharky } from "@sharky/sdk";

const sharky = new Sharky("project-token");

// Catalog / portfolio
const catalog = await sharky.listCatalog({ q: "app" });
const item = await sharky.getCatalog("itemId");

// Taxonomy
const categories = await sharky.listCategories();
const tags = await sharky.listTags();

// Blog
const posts = await sharky.listPosts();
const post = await sharky.getPost("postId");

// Site metadata (SEO / theme / socials)
const meta = await sharky.getMeta();

// Contact capture
await sharky.submitContact({
  name: "Ana",
  email: "ana@example.com",
  message: "I'd like a quote.",
  formName: "DemoForm", // optional: labels the lead in the backoffice
  extraFields: [{ key: "Company", value: "Acme" }],
});
```

## Configuration

```ts
new Sharky("project-token", {
  apiUrl: "https://sharky-backoffice-api.fly.dev", // default
  fetch: customFetch,   // optional (SSR / Node < 18)
  timeoutMs: 8000,      // optional per-request timeout
});
```

The client only calls Sharky's **public** endpoints, so it is safe in the
browser. The `project-token` is your Sharky project identifier.

## API

| Method | Returns | Endpoint |
|---|---|---|
| `listCatalog(filters?)` | `SharkyItem[]` | `GET /catalog/public/:token?type=CATALOG` |
| `getCatalog(itemId)` | `SharkyItem` | `GET /catalog/public/:token/:itemId` |
| `listPosts(filters?)` | `SharkyItem[]` | `GET /catalog/public/:token?type=POST` |
| `getPost(itemId)` | `SharkyItem` | `GET /catalog/public/:token/:itemId` |
| `listCategories()` | `SharkyField[]` | `GET /field/public/:token?type=CATEGORY` |
| `listTags()` | `SharkyField[]` | `GET /field/public/:token?type=TAG` |
| `getMeta()` | `SharkyMeta` | `GET /projects/public/:token/meta` |
| `submitContact(input)` | `void` | `POST /contacts/:token` |

`filters`: `{ q?, categories?: string[], tags?: string[], take?, skip? }`.

## Errors

Every failure throws a `SharkyError` with `status` and `body` when available:

```ts
import { SharkyError } from "@sharky/sdk";

try {
  await sharky.getCatalog("missing");
} catch (err) {
  if (err instanceof SharkyError) console.error(err.status, err.message);
}
```

## Meta example (Next.js)

```ts
export async function generateMetadata() {
  const meta = await new Sharky(process.env.SHARKY_TOKEN!).getMeta();
  return { title: meta.name, description: meta.description ?? undefined };
}
```
